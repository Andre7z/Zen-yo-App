import { apiRequest } from '../api'

export type Identificado = { id: number }

export type Faixa = Identificado & { nome: string; tipo: 'Kyu' | 'Dan'; ordem: number }
export type Dojo = Identificado & { nome: string; cidade: string | null }
export type Turma = Identificado & { nome: string; dojo_id: number; professor_id: number | null }
export type Aluno = Identificado & {
  nome: string
  cpf: string
  data_nascimento: string | null
  faixa_id: number
  turma: string | null
  tamanho_kimono: string
  tamanho_faixa: string
  codigo_zempo: string
}
export type Atividade = Identificado & {
  tipo: 'frequencia' | 'entrega_de_kimono' | 'troca_de_faixa'
  nome: string
  data: string
  local: string | null
  descricao: string | null
  aluno_ids: number[]
  aluno_ids_pagos: number[]
  nova_faixa: string | null
  presenca: boolean | null
}
export type Anexo = Identificado & {
  titulo: string
  categoria: 'Calendarios' | 'Panilhas' | 'Fichas' | 'Regulamento' | 'Regulamentos' | 'Outro'
  descricao: string | null
  nome_arquivo: string | null
  arquivo_url: string | null
  link: string | null
  criado_em: string
}

function recurso<T extends Identificado>(rota: string) {
  return {
    listar: () => apiRequest<T[]>(rota),
    criar: (dados: object) => apiRequest<T>(rota, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados),
    }),
    atualizar: (id: number, dados: object) => apiRequest<T>(`${rota}${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados),
    }),
    apagar: (id: number) => apiRequest<void>(`${rota}${id}`, { method: 'DELETE' }),
  }
}

export const alunosApi = recurso<Aluno>('/aluno/')
export const atividadesApi = recurso<Atividade>('/atividades/')
export const anexosApi = recurso<Anexo>('/anexos/')
export const dojosApi = recurso<Dojo>('/dojos/')
export const faixasApi = recurso<Faixa>('/faixas/')
export const turmasApi = recurso<Turma>('/turmas/')

export function relatorioAtividade(id: number) {
  return apiRequest<Array<Record<string, string | boolean | null>>>(`/atividades/${id}/relatorio`)
}
