import { useEffect, useState, type FormEvent } from 'react'
import { FileText, Pencil, Plus, Trash2, X } from 'lucide-react'
import { BotaoIcone, CampoModulo, PaginaModulo } from '../components/PaginaModulo'
import { useRecurso } from '../hooks/use-recurso'
import { atividadesApi, alunosApi, relatorioAtividade, type Aluno, type Atividade } from '../servicos/dominio'

const hoje = new Date().toISOString().slice(0, 10)
const vazio = { tipo: 'frequencia' as Atividade['tipo'], nome: '', data: hoje, local: '', descricao: '', aluno_ids: [] as number[], aluno_ids_pagos: [] as number[], nova_faixa: '', presenca: true }
type DadosAtividade = typeof vazio

export function AtividadesPage() {
  const recurso = useRecurso(atividadesApi)
  const [alunos, setAlunos] = useState<Aluno[]>([])
  const [erroAlunos, setErroAlunos] = useState('')
  const [dados, setDados] = useState<DadosAtividade>(vazio)
  const [editando, setEditando] = useState<number | null>(null)
  const [formAberto, setFormAberto] = useState(false)
  const [relatorio, setRelatorio] = useState<{ titulo: string; linhas: Array<Record<string, string | boolean | null>> } | null>(null)
  const [erroRelatorio, setErroRelatorio] = useState('')

  useEffect(() => {
    void alunosApi.listar().then(setAlunos).catch((falha: unknown) => {
      setErroAlunos(falha instanceof Error ? falha.message : 'Não foi possível carregar os alunos.')
    })
  }, [])

  function iniciarEdicao(item: Atividade) {
    setDados({
      tipo: item.tipo,
      nome: item.nome,
      data: item.data,
      local: item.local ?? '',
      descricao: item.descricao ?? '',
      aluno_ids: item.aluno_ids,
      aluno_ids_pagos: item.aluno_ids_pagos ?? [],
      nova_faixa: item.nova_faixa ?? '',
      presenca: item.presenca ?? true,
    })
    setEditando(item.id)
    setFormAberto(true)
  }

  async function salvar(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const payload = {
      ...dados,
      nome: dados.nome.trim(),
      local: dados.local.trim() || null,
      descricao: dados.descricao.trim() || null,
      nova_faixa: dados.tipo === 'troca_de_faixa' ? dados.nova_faixa.trim() || null : null,
      presenca: dados.tipo === 'frequencia' ? dados.presenca : null,
    }
    const sucesso = await recurso.executar(() => editando
      ? atividadesApi.atualizar(editando, payload)
      : atividadesApi.criar(payload))
    if (sucesso) {
      setDados(vazio)
      setEditando(null)
      setFormAberto(false)
    }
  }

  async function apagar(item: Atividade) {
    if (window.confirm(`Excluir a atividade ${item.nome}?`)) await recurso.executar(() => atividadesApi.apagar(item.id))
  }

  async function verRelatorio(item: Atividade) {
    setErroRelatorio('')
    try {
      setRelatorio({ titulo: item.nome, linhas: await relatorioAtividade(item.id) })
    } catch (falha) {
      setErroRelatorio(falha instanceof Error ? falha.message : 'Não foi possível gerar o relatório.')
    }
  }

  return (
    <PaginaModulo kicker="ROTINA DO DOJÔ" titulo="Atividades" descricao="Registre frequência, entrega de kimonos e graduações." carregando={recurso.carregando} erro={recurso.erro || erroAlunos} recarregar={() => { void recurso.carregar() }}>
      <div className="module-toolbar"><p>{recurso.itens.length} {recurso.itens.length === 1 ? 'atividade' : 'atividades'}</p><button className="module-primary" type="button" onClick={() => { setDados(vazio); setEditando(null); setFormAberto((aberto) => !aberto) }}>{formAberto ? <X size={16} /> : <Plus size={16} />}{formAberto ? 'Fechar formulário' : 'Nova atividade'}</button></div>

      {formAberto && (
        <form className="module-form" onSubmit={salvar}>
          <div className="module-form-heading"><h2>{editando ? 'Editar atividade' : 'Nova atividade'}</h2></div>
          <div className="module-form-grid">
            <CampoModulo rotulo="Tipo"><select value={dados.tipo} onChange={(event) => setDados({ ...dados, tipo: event.target.value as Atividade['tipo'] })}><option value="frequencia">Frequência</option><option value="entrega_de_kimono">Entrega de kimono</option><option value="troca_de_faixa">Troca de faixa</option></select></CampoModulo>
            <CampoModulo rotulo="Nome"><input required maxLength={120} value={dados.nome} onChange={(event) => setDados({ ...dados, nome: event.target.value })} /></CampoModulo>
            <CampoModulo rotulo="Data"><input required type="date" value={dados.data} onChange={(event) => setDados({ ...dados, data: event.target.value })} /></CampoModulo>
            <CampoModulo rotulo="Local"><input value={dados.local} onChange={(event) => setDados({ ...dados, local: event.target.value })} /></CampoModulo>
            {dados.tipo === 'troca_de_faixa' && <CampoModulo rotulo="Nova faixa"><input value={dados.nova_faixa} onChange={(event) => setDados({ ...dados, nova_faixa: event.target.value })} /></CampoModulo>}
            {dados.tipo === 'frequencia' && <CampoModulo rotulo="Presença"><select value={String(dados.presenca)} onChange={(event) => setDados({ ...dados, presenca: event.target.value === 'true' })}><option value="true">Presente</option><option value="false">Ausente</option></select></CampoModulo>}
            <CampoModulo rotulo="Descrição"><textarea rows={3} value={dados.descricao} onChange={(event) => setDados({ ...dados, descricao: event.target.value })} /></CampoModulo>
          </div>
          <fieldset className="module-checks"><legend>Alunos participantes</legend><div className="activity-participant-list">{alunos.map((aluno) => {
            const adicionado = dados.aluno_ids.includes(aluno.id)
            const pago = dados.aluno_ids_pagos.includes(aluno.id)
            return <div className="activity-participant-row" key={aluno.id}>
              <label className="activity-participant-name"><input aria-label={`Adicionar ${aluno.nome}`} type="checkbox" checked={adicionado} onChange={(event) => setDados({
                ...dados,
                aluno_ids: event.target.checked ? [...dados.aluno_ids, aluno.id] : dados.aluno_ids.filter((id) => id !== aluno.id),
                aluno_ids_pagos: event.target.checked ? dados.aluno_ids_pagos : dados.aluno_ids_pagos.filter((id) => id !== aluno.id),
              })} /><span>{aluno.nome}</span></label>
              {adicionado ? <label className="activity-payment"><input aria-label={`Pagamento confirmado de ${aluno.nome}`} type="checkbox" checked={pago} onChange={(event) => setDados({ ...dados, aluno_ids_pagos: event.target.checked ? [...dados.aluno_ids_pagos, aluno.id] : dados.aluno_ids_pagos.filter((id) => id !== aluno.id) })} /><span>Pago</span></label> : <span className="activity-not-added">Não adicionado</span>}
            </div>
          })}{!alunos.length && <small>Cadastre alunos antes de criar uma atividade.</small>}</div></fieldset>
          <div className="module-form-actions"><button className="module-primary" disabled={recurso.salvando || !alunos.length}>{recurso.salvando ? 'Salvando...' : editando ? 'Salvar alterações' : 'Criar atividade'}</button><button className="module-secondary" type="button" onClick={() => setFormAberto(false)}>Cancelar</button></div>
        </form>
      )}

      {erroRelatorio && <p className="module-error" role="alert">{erroRelatorio}</p>}
      {relatorio && <section className="module-form" aria-label="Relatório da atividade"><div className="module-form-heading"><h2>Relatório · {relatorio.titulo}</h2><button className="module-secondary" type="button" onClick={() => setRelatorio(null)}>Fechar</button></div>{relatorio.linhas.length ? relatorio.linhas.map((linha, indice) => <pre className="module-report" key={indice}>{Object.entries(linha).map(([chave, valor]) => `${chave}: ${String(valor ?? '—')}`).join('\n')}</pre>) : <p>Nenhum aluno foi associado à atividade.</p>}</section>}

      <div className="module-list" aria-label="Lista de atividades">
        {recurso.itens.map((item) => (
          <article className="module-record" key={item.id}><div className="record-main"><strong>{item.nome}</strong><span>{item.data} · {item.tipo.replaceAll('_', ' ')} · {item.aluno_ids.length} alunos · {item.aluno_ids_pagos?.length ?? 0} pagos{item.local ? ` · ${item.local}` : ''}</span></div><div className="record-actions"><BotaoIcone label={`Relatório de ${item.nome}`} onClick={() => void verRelatorio(item)}><FileText size={16} /></BotaoIcone><BotaoIcone label={`Editar ${item.nome}`} onClick={() => iniciarEdicao(item)}><Pencil size={16} /></BotaoIcone><BotaoIcone label={`Excluir ${item.nome}`} onClick={() => void apagar(item)}><Trash2 size={16} /></BotaoIcone></div></article>
        ))}
        {!recurso.itens.length && <p className="module-empty">Nenhuma atividade cadastrada.</p>}
      </div>
    </PaginaModulo>
  )
}
