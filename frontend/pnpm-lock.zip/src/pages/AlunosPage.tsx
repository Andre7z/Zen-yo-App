import { useEffect, useState, type FormEvent } from 'react'
import { Pencil, Plus, Trash2, X } from 'lucide-react'
import { alunosApi, faixasApi, type Aluno, type Faixa } from '../servicos/dominio'
import { useRecurso } from '../hooks/use-recurso'
import { BotaoIcone, CampoModulo, PaginaModulo } from '../components/PaginaModulo'

const vazio = {
  nome: '', cpf: '', data_nascimento: '', faixa_id: '', turma: '',
  tamanho_kimono: '', tamanho_faixa: '', codigo_zempo: '',
}
type DadosAluno = typeof vazio

export function AlunosPage() {
  const recurso = useRecurso(alunosApi)
  const [faixas, setFaixas] = useState<Faixa[]>([])
  const [erroFaixas, setErroFaixas] = useState('')
  const [dados, setDados] = useState<DadosAluno>(vazio)
  const [editando, setEditando] = useState<number | null>(null)
  const [formAberto, setFormAberto] = useState(false)

  useEffect(() => {
    void faixasApi.listar().then(setFaixas).catch((falha: unknown) => {
      setErroFaixas(falha instanceof Error ? falha.message : 'Não foi possível carregar as faixas.')
    })
  }, [])

  function iniciarEdicao(aluno: Aluno) {
    setDados({
      nome: aluno.nome,
      cpf: aluno.cpf,
      data_nascimento: aluno.data_nascimento ?? '',
      faixa_id: String(aluno.faixa_id),
      turma: aluno.turma ?? '',
      tamanho_kimono: aluno.tamanho_kimono,
      tamanho_faixa: aluno.tamanho_faixa,
      codigo_zempo: aluno.codigo_zempo,
    })
    setEditando(aluno.id)
    setFormAberto(true)
  }

  async function salvar(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const payload = {
      nome: dados.nome.trim(),
      cpf: dados.cpf.trim(),
      data_nascimento: dados.data_nascimento || null,
      faixa_id: Number(dados.faixa_id),
      turma: dados.turma.trim() || null,
      tamanho_kimono: dados.tamanho_kimono.trim(),
      tamanho_faixa: dados.tamanho_faixa.trim(),
      codigo_zempo: dados.codigo_zempo.trim(),
    }
    const sucesso = await recurso.executar(() => editando
      ? alunosApi.atualizar(editando, payload)
      : alunosApi.criar(payload))
    if (sucesso) {
      setDados(vazio)
      setEditando(null)
      setFormAberto(false)
    }
  }

  async function apagar(aluno: Aluno) {
    if (window.confirm(`Excluir o cadastro de ${aluno.nome}?`)) {
      await recurso.executar(() => alunosApi.apagar(aluno.id))
    }
  }

  return (
    <PaginaModulo kicker="GESTÃO DO DOJÔ" titulo="Alunos" descricao="Cadastros, graduações e informações de cada aluno." carregando={recurso.carregando} erro={recurso.erro || erroFaixas} recarregar={() => { void recurso.carregar() }}>
      <div className="module-toolbar">
        <p>{recurso.itens.length} {recurso.itens.length === 1 ? 'aluno cadastrado' : 'alunos cadastrados'}</p>
        <button className="module-primary" type="button" onClick={() => { setDados(vazio); setEditando(null); setFormAberto((aberto) => !aberto) }}>
          {formAberto ? <X size={16} /> : <Plus size={16} />}{formAberto ? 'Fechar formulário' : 'Novo aluno'}
        </button>
      </div>

      {formAberto && (
        <form className="module-form" onSubmit={salvar}>
          <div className="module-form-heading"><h2>{editando ? 'Editar aluno' : 'Novo aluno'}</h2></div>
          <div className="module-form-grid">
            <CampoModulo rotulo="Nome completo"><input required minLength={2} value={dados.nome} onChange={(event) => setDados({ ...dados, nome: event.target.value })} /></CampoModulo>
            <CampoModulo rotulo="CPF"><input required minLength={11} value={dados.cpf} onChange={(event) => setDados({ ...dados, cpf: event.target.value })} /></CampoModulo>
            <CampoModulo rotulo="Data de nascimento"><input type="date" value={dados.data_nascimento} onChange={(event) => setDados({ ...dados, data_nascimento: event.target.value })} /></CampoModulo>
            <CampoModulo rotulo="Faixa"><select required value={dados.faixa_id} onChange={(event) => setDados({ ...dados, faixa_id: event.target.value })}><option value="">Selecione</option>{faixas.map((faixa) => <option key={faixa.id} value={faixa.id}>{faixa.nome}</option>)}</select></CampoModulo>
            <CampoModulo rotulo="Turma"><input minLength={2} value={dados.turma} onChange={(event) => setDados({ ...dados, turma: event.target.value })} placeholder="Opcional" /></CampoModulo>
            <CampoModulo rotulo="Tamanho do kimono"><input required minLength={2} value={dados.tamanho_kimono} onChange={(event) => setDados({ ...dados, tamanho_kimono: event.target.value })} /></CampoModulo>
            <CampoModulo rotulo="Tamanho da faixa"><input required value={dados.tamanho_faixa} onChange={(event) => setDados({ ...dados, tamanho_faixa: event.target.value })} /></CampoModulo>
            <CampoModulo rotulo="Código Zempo"><input required minLength={2} value={dados.codigo_zempo} onChange={(event) => setDados({ ...dados, codigo_zempo: event.target.value })} /></CampoModulo>
          </div>
          <div className="module-form-actions"><button className="module-primary" disabled={recurso.salvando || Boolean(erroFaixas)}>{recurso.salvando ? 'Salvando...' : editando ? 'Salvar alterações' : 'Cadastrar aluno'}</button><button className="module-secondary" type="button" onClick={() => setFormAberto(false)}>Cancelar</button></div>
        </form>
      )}

      <div className="module-list" aria-label="Lista de alunos">
        {recurso.itens.map((aluno) => (
          <article className="module-record" key={aluno.id}>
            <div className="record-main"><strong>{aluno.nome}</strong><span>CPF {aluno.cpf} · {faixas.find((faixa) => faixa.id === aluno.faixa_id)?.nome ?? 'Faixa não encontrada'}{aluno.turma ? ` · ${aluno.turma}` : ''}</span></div>
            <div className="record-actions"><BotaoIcone label={`Editar ${aluno.nome}`} onClick={() => iniciarEdicao(aluno)}><Pencil size={16} /></BotaoIcone><BotaoIcone label={`Excluir ${aluno.nome}`} onClick={() => void apagar(aluno)}><Trash2 size={16} /></BotaoIcone></div>
          </article>
        ))}
        {!recurso.itens.length && <p className="module-empty">Nenhum aluno cadastrado.</p>}
      </div>
    </PaginaModulo>
  )
}
