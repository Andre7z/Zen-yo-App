import { CrudCatalogo } from '../components/CrudCatalogo'
import { dojosApi, type Dojo } from '../servicos/dominio'

export function DojosPage() {
  return <CrudCatalogo<Dojo>
    api={dojosApi}
    titulo="Dojos"
    rotuloNovo="Novo dojo"
    entidade="dojo"
    kicker="CONFIGURAÇÃO"
    descricao="Cadastre os locais e unidades vinculados às turmas."
    campos={[{ nome: 'nome', rotulo: 'Nome do dojo' }, { nome: 'cidade', rotulo: 'Cidade', obrigatorio: false }]}
    colunas={[{ rotulo: 'Nome', valor: (dojo) => dojo.nome }, { rotulo: 'Cidade', valor: (dojo) => dojo.cidade ?? 'Não informada' }]}
  />
}
