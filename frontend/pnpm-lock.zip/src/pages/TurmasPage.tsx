import { useEffect, useState, type FormEvent } from 'react'
import { Pencil, Plus, Trash2, X } from 'lucide-react'
import { BotaoIcone, CampoModulo, PaginaModulo } from '../components/PaginaModulo'
import { useRecurso } from '../hooks/use-recurso'
import { dojosApi, turmasApi, type Dojo, type Turma } from '../servicos/dominio'

const vazio = { nome: '', dojo_id: '', professor_id: '' }
type DadosTurma = typeof vazio

export function TurmasPage() {
  const recurso = useRecurso(turmasApi)
  const [dojos, setDojos] = useState<Dojo[]>([])
  const [erroDojos, setErroDojos] = useState('')
  const [dados, setDados] = useState<DadosTurma>(vazio)
  const [editando, setEditando] = useState<number | null>(null)
  const [formAberto, setFormAberto] = useState(false)

  useEffect(() => {
    void dojosApi.listar().then(setDojos).catch((falha: unknown) => {
      setErroDojos(falha instanceof Error ? falha.message : 'Não foi possível carregar os dojos.')
    })
  }, [])

  function iniciarEdicao(turma: Turma) {
    setDados({ nome: turma.nome, dojo_id: String(turma.dojo_id), professor_id: turma.professor_id === null ? '' : String(turma.professor_id) })
    setEditando(turma.id)
    setFormAberto(true)
  }

  async function salvar(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const payload = { nome: dados.nome.trim(), dojo_id: Number(dados.dojo_id), professor_id: dados.professor_id ? Number(dados.professor_id) : null }
    const sucesso = await recurso.executar(() => editando
      ? turmasApi.atualizar(editando, payload)
      : turmasApi.criar(payload))
    if (sucesso) {
      setDados(vazio)
      setEditando(null)
      setFormAberto(false)
    }
  }

  async function apagar(turma: Turma) {
    if (window.confirm(`Excluir a turma ${turma.nome}?`)) await recurso.executar(() => turmasApi.apagar(turma.id))
  }

  return (
    <PaginaModulo kicker="CONFIGURAÇÃO" titulo="Turmas" descricao="Organize as turmas e seus vínculos com os dojos." carregando={recurso.carregando} erro={recurso.erro || erroDojos} recarregar={() => { void recurso.carregar() }}>
      <div className="module-toolbar"><p>{recurso.itens.length} turmas</p><button className="module-primary" type="button" onClick={() => { setDados(vazio); setEditando(null); setFormAberto((atual) => !atual) }}>{formAberto ? <X size={16} /> : <Plus size={16} />}{formAberto ? 'Fechar formulário' : 'Nova turma'}</button></div>
      {formAberto && <form className="module-form" onSubmit={salvar}><div className="module-form-heading"><h2>{editando ? 'Editar turma' : 'Nova turma'}</h2></div><div className="module-form-grid">
        <CampoModulo rotulo="Nome da turma"><input required minLength={2} value={dados.nome} onChange={(event) => setDados({ ...dados, nome: event.target.value })} /></CampoModulo>
        <CampoModulo rotulo="Dojo"><select required value={dados.dojo_id} onChange={(event) => setDados({ ...dados, dojo_id: event.target.value })}><option value="">Selecione</option>{dojos.map((dojo) => <option key={dojo.id} value={dojo.id}>{dojo.nome}{dojo.cidade ? ` · ${dojo.cidade}` : ''}</option>)}</select></CampoModulo>
        <CampoModulo rotulo="ID do professor" dica="Opcional; o professor precisa pertencer ao dojo escolhido."><input type="number" min={1} value={dados.professor_id} onChange={(event) => setDados({ ...dados, professor_id: event.target.value })} /></CampoModulo>
      </div><div className="module-form-actions"><button className="module-primary" disabled={recurso.salvando || Boolean(erroDojos) || !dojos.length}>{recurso.salvando ? 'Salvando...' : 'Salvar turma'}</button><button className="module-secondary" type="button" onClick={() => setFormAberto(false)}>Cancelar</button></div></form>}
      <div className="module-list" aria-label="Lista de turmas">{recurso.itens.map((turma) => <article className="module-record" key={turma.id}><div className="record-main"><strong>{turma.nome}</strong><span>{dojos.find((dojo) => dojo.id === turma.dojo_id)?.nome ?? `Dojo #${turma.dojo_id}`} · Professor {turma.professor_id ?? 'não definido'}</span></div><div className="record-actions"><BotaoIcone label={`Editar ${turma.nome}`} onClick={() => iniciarEdicao(turma)}><Pencil size={16} /></BotaoIcone><BotaoIcone label={`Excluir ${turma.nome}`} onClick={() => void apagar(turma)}><Trash2 size={16} /></BotaoIcone></div></article>)}{!recurso.itens.length && <p className="module-empty">Nenhuma turma cadastrada.</p>}</div>
    </PaginaModulo>
  )
}
