import { cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import App from './App'
import { clearToken, saveToken } from './api'
import { ROTAS } from './routes'

const usuario = { id: 4, nome: 'Ana Professora', email: 'ana@example.com', dojo_id: 1 }
const faixa = { id: 2, nome: 'Amarela', tipo: 'Kyu', ordem: 4 }
const dojo = { id: 1, nome: 'Dojo Central', cidade: 'Campinas' }
const aluno = {
  id: 7,
  nome: 'Caio Silva',
  cpf: '12345678901',
  data_nascimento: null,
  faixa_id: 2,
  turma: 'Infantil',
  tamanho_kimono: 'M2',
  tamanho_faixa: '2',
  codigo_zempo: 'ZP001',
}
const atividade = {
  id: 9,
  tipo: 'frequencia',
  nome: 'Treino infantil',
  data: '2026-10-13',
  local: 'Tatame 1',
  descricao: null,
  aluno_ids: [7],
  aluno_ids_pagos: [],
  nova_faixa: null,
  presenca: true,
}
const anexo = {
  id: 3,
  titulo: 'Calendário anual',
  categoria: 'Calendarios',
  descricao: null,
  nome_arquivo: 'calendario.pdf',
  arquivo_url: null,
  link: 'https://example.com/calendario',
  criado_em: '2026-10-13',
}
const turma = { id: 5, nome: 'Infantil A', dojo_id: 1, professor_id: 4 }
const requisicao = vi.fn<typeof fetch>()

function configurarApi() {
  requisicao.mockImplementation(async (input, init) => {
    const caminho = new URL(String(input)).pathname
    const metodo = init?.method ?? 'GET'
    if (caminho === '/usuarios/eu') return Response.json(usuario)
    if (metodo === 'POST' || metodo === 'PATCH') {
      const dados = JSON.parse(String(init?.body ?? '{}')) as Record<string, unknown>
      return Response.json({ id: 101, ...dados }, { status: metodo === 'POST' ? 201 : 200 })
    }
    if (metodo === 'DELETE') return new Response(null, { status: 204 })
    if (caminho === '/aluno/') return Response.json([aluno])
    if (caminho === '/faixas/') return Response.json([faixa])
    if (caminho === '/dojos/') return Response.json([dojo])
    if (caminho === '/turmas/') return Response.json([turma])
    if (caminho === '/atividades/') return Response.json([atividade])
    if (caminho === '/anexos/') return Response.json([anexo])
    if (/^\/atividades\/\d+\/relatorio$/.test(caminho)) return Response.json([])
    return Response.json({ detail: `Rota não encontrada: ${caminho}` }, { status: 404 })
  })
  vi.stubGlobal('fetch', requisicao)
}

function abrir(path: string) {
  saveToken('token-de-teste')
  window.history.replaceState({}, '', path)
  return render(<App />)
}

beforeEach(() => {
  clearToken()
  localStorage.clear()
  requisicao.mockReset()
  configurarApi()
})

afterEach(() => {
  cleanup()
  clearToken()
  vi.unstubAllGlobals()
})

describe('telas conectadas aos recursos FastAPI', () => {
  it('lista alunos e cria um cadastro com a faixa selecionada', async () => {
    abrir(ROTAS.alunos)
    expect(await screen.findByText('Caio Silva')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: 'Novo aluno' }))
    fireEvent.change(screen.getByLabelText('Nome completo'), { target: { value: 'Bruna Costa' } })
    fireEvent.change(screen.getByLabelText('CPF'), { target: { value: '98765432100' } })
    fireEvent.change(screen.getByLabelText('Faixa'), { target: { value: '2' } })
    fireEvent.change(screen.getByLabelText('Tamanho do kimono'), { target: { value: 'M1' } })
    fireEvent.change(screen.getByLabelText('Tamanho da faixa'), { target: { value: '1' } })
    fireEvent.change(screen.getByLabelText('Código Zempo'), { target: { value: 'ZP002' } })
    fireEvent.click(screen.getByRole('button', { name: 'Cadastrar aluno' }))

    await waitFor(() => expect(requisicao).toHaveBeenCalledWith(expect.stringContaining('/aluno/'), expect.objectContaining({ method: 'POST' })))
    const envio = requisicao.mock.calls.find(([url, init]) => String(url).endsWith('/aluno/') && init?.method === 'POST')
    expect(JSON.parse(String(envio?.[1]?.body))).toMatchObject({ nome: 'Bruna Costa', faixa_id: 2, codigo_zempo: 'ZP002' })
  })

  it('cria atividade com participantes pelos IDs exigidos pelo backend', async () => {
    abrir(ROTAS.atividades)
    expect(await screen.findByText('Treino infantil')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: 'Nova atividade' }))
    fireEvent.change(screen.getByLabelText('Nome'), { target: { value: 'Treino de sábado' } })
    fireEvent.click(screen.getByLabelText('Adicionar Caio Silva'))
    fireEvent.click(screen.getByLabelText('Pagamento confirmado de Caio Silva'))
    fireEvent.click(screen.getByRole('button', { name: 'Criar atividade' }))

    await waitFor(() => expect(requisicao).toHaveBeenCalledWith(expect.stringContaining('/atividades/'), expect.objectContaining({ method: 'POST' })))
    const envio = requisicao.mock.calls.find(([url, init]) => String(url).endsWith('/atividades/') && init?.method === 'POST')
    expect(JSON.parse(String(envio?.[1]?.body))).toMatchObject({ nome: 'Treino de sábado', tipo: 'frequencia', aluno_ids: [7], aluno_ids_pagos: [7] })
  })

  it('mantém atalhos mobile e abre as opções secundárias no menu lateral', async () => {
    abrir(ROTAS.alunos)
    await screen.findByRole('navigation', { name: 'Navegação principal' })
    const atalhos = screen.getByRole('navigation', { name: 'Acesso rápido' })
    for (const pagina of ['Início', 'Atividades', 'Alunos', 'Anexos', 'Calendário']) {
      expect(within(atalhos).getByRole('link', { name: pagina })).toBeTruthy()
    }

    fireEvent.click(screen.getByRole('button', { name: 'Abrir menu' }))
    expect(screen.getByRole('button', { name: 'Fechar menu' }).getAttribute('aria-expanded')).toBe('true')
    fireEvent.click(screen.getByRole('link', { name: 'Dojos' }))

    expect(await screen.findByRole('heading', { name: 'Dojos' })).toBeTruthy()
    expect(screen.getByRole('button', { name: 'Abrir menu' }).getAttribute('aria-expanded')).toBe('false')
  })

  it('edita e exclui aluno usando os endpoints correspondentes', async () => {
    vi.spyOn(window, 'confirm').mockReturnValue(true)
    abrir(ROTAS.alunos)
    expect(await screen.findByText('Caio Silva')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: 'Editar Caio Silva' }))
    fireEvent.change(screen.getByLabelText('Nome completo'), { target: { value: 'Caio Silva Neto' } })
    fireEvent.click(screen.getByRole('button', { name: 'Salvar alterações' }))

    await waitFor(() => expect(requisicao).toHaveBeenCalledWith(expect.stringContaining('/aluno/7'), expect.objectContaining({ method: 'PATCH' })))
    fireEvent.click(screen.getByRole('button', { name: 'Excluir Caio Silva' }))
    await waitFor(() => expect(requisicao).toHaveBeenCalledWith(expect.stringContaining('/aluno/7'), expect.objectContaining({ method: 'DELETE' })))
  })

  it('consulta o relatório de uma atividade pela rota específica', async () => {
    abrir(ROTAS.atividades)
    expect(await screen.findByText('Treino infantil')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: 'Relatório de Treino infantil' }))

    expect(await screen.findByRole('region', { name: 'Relatório da atividade' })).toBeTruthy()
    expect(requisicao).toHaveBeenCalledWith(expect.stringContaining('/atividades/9/relatorio'), expect.anything())
  })

  it('lista e cadastra anexos como metadados e links', async () => {
    abrir(ROTAS.anexos)
    expect(await screen.findByText('Calendário anual')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: 'Novo anexo' }))
    fireEvent.change(screen.getByLabelText('Título'), { target: { value: 'Regulamento 2027' } })
    fireEvent.change(screen.getByLabelText('Categoria'), { target: { value: 'Regulamentos' } })
    fireEvent.change(screen.getByLabelText('Link externo'), { target: { value: 'https://example.com/regulamento' } })
    fireEvent.click(screen.getByRole('button', { name: 'Cadastrar anexo' }))

    await waitFor(() => expect(requisicao).toHaveBeenCalledWith(expect.stringContaining('/anexos/'), expect.objectContaining({ method: 'POST' })))
    const envio = requisicao.mock.calls.find(([url, init]) => String(url).endsWith('/anexos/') && init?.method === 'POST')
    expect(JSON.parse(String(envio?.[1]?.body))).toMatchObject({ titulo: 'Regulamento 2027', categoria: 'Regulamentos' })
  })

  it('lista e cria dojos', async () => {
    abrir(ROTAS.dojos)
    expect(await screen.findByText('Dojo Central')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: 'Novo dojo' }))
    fireEvent.change(screen.getByLabelText('Nome do dojo'), { target: { value: 'Dojo Norte' } })
    fireEvent.click(screen.getByRole('button', { name: 'Salvar' }))

    await waitFor(() => expect(requisicao).toHaveBeenCalledWith(expect.stringContaining('/dojos/'), expect.objectContaining({ method: 'POST' })))
  })

  it('lista e cria faixas com tipo e ordem validados', async () => {
    abrir(ROTAS.faixas)
    expect(await screen.findByText('Amarela')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: 'Nova faixa' }))
    fireEvent.change(screen.getByLabelText('Nome da faixa'), { target: { value: 'Laranja' } })
    fireEvent.change(screen.getByLabelText('Classificação'), { target: { value: 'Kyu' } })
    fireEvent.change(screen.getByLabelText('Ordem'), { target: { value: '5' } })
    fireEvent.click(screen.getByRole('button', { name: 'Salvar' }))

    await waitFor(() => expect(requisicao).toHaveBeenCalledWith(expect.stringContaining('/faixas/'), expect.objectContaining({ method: 'POST' })))
    const envio = requisicao.mock.calls.find(([url, init]) => String(url).endsWith('/faixas/') && init?.method === 'POST')
    expect(JSON.parse(String(envio?.[1]?.body))).toMatchObject({ nome: 'Laranja', tipo: 'Kyu', ordem: 5 })
  })

  it('lista e cria turmas vinculadas a um dojo', async () => {
    abrir(ROTAS.turmas)
    expect(await screen.findByText('Infantil A')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: 'Nova turma' }))
    fireEvent.change(screen.getByLabelText('Nome da turma'), { target: { value: 'Juvenil' } })
    fireEvent.change(screen.getByLabelText('Dojo'), { target: { value: '1' } })
    fireEvent.click(screen.getByRole('button', { name: 'Salvar turma' }))

    await waitFor(() => expect(requisicao).toHaveBeenCalledWith(expect.stringContaining('/turmas/'), expect.objectContaining({ method: 'POST' })))
    const envio = requisicao.mock.calls.find(([url, init]) => String(url).endsWith('/turmas/') && init?.method === 'POST')
    expect(JSON.parse(String(envio?.[1]?.body))).toMatchObject({ nome: 'Juvenil', dojo_id: 1, professor_id: null })
  })

  it('mostra a agenda derivada das atividades cadastradas', async () => {
    abrir(ROTAS.calendario)
    expect(await screen.findByText('Treino infantil')).toBeTruthy()
    expect(screen.getByText(/13 de outubro de 2026/i)).toBeTruthy()
  })
})
